/* Exame Computacao Grafica
Aluna: Isis Yasmim Almeida de Sousa
 */
#include <GL/gl.h>
#include <GL/glut.h>
#include <stdio.h>
GLfloat red=1.0f, green=1.0f, blue=0.0f;
GLfloat largura, altura, aspecto;
int win=50;
int ang = 0;

void Timer(int x){
    ang += 5;
    if (ang > 360) ang =0;
    glutPostRedisplay();
    glutTimerFunc(35, Timer, 1);
}

void Desenha(void){
    glClear(GL_COLOR_BUFFER_BIT); // limpando o buffer de trabalho

    // triangulo
    glPushMatrix();
        glRotatef(ang, 0, 1, 0);
        glBegin(GL_LINES);
            glColor3f(1.0f, 0.0f, 0.0f);
            glVertex2f(-20.0f, 0.0f);
            glVertex2f(-15.0f, 15.0f);

            glColor3f(0.0f, 1.0f, 0.0f);
            glVertex2f(-15.0f, 15.0f);
            glVertex2f(-10.0f, 0.0f);

            glColor3f(0.0f, 0.0f, 1.0f);
            glVertex2f(-10.0f, 0.0f);
            glVertex2f(-20.0f, 0.0f);
        glEnd();
    glPopMatrix();

    //quadrado
    glPushMatrix();
        glColor3f(red, green, blue);
        glRotatef(ang, 1, 0, 0);
        glBegin(GL_QUADS);
            glVertex2f(10.0f, 0.0f);
            glVertex2f(10.0f, 15.0f);
            glVertex2f(20.0f, 15.0f);
            glVertex2f(20.0f, 0.0f);
        glEnd();
    glPopMatrix();

    glFlush();

}

void AlteraTamanhoJanela(GLsizei w, GLsizei h){
    if(h==0) h=1;
    // Atualiza as vari�veis
    glViewport(0,0,w,h);
    largura = w/2;
    altura = h;
    aspecto = (float) largura/altura;
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-win*aspecto, win*aspecto, -win, win);

}

void Teclado(unsigned char tecla, int x, int y){
    switch(tecla){
        case 27: // ESC
                exit(0);
                break;
        case 'b':
            red=1.0f;
            blue=1.0f;
            green=1.0f;
        break;
        case 'a':
            red=1.0f;
            blue=0.0f;
            green=1.0f;
            break;
        case 'c':
            red=0.0f;
            blue=1.0f;
            green=1.0f;
            break;
        case 'm':
            red=1.0f;
            blue=1.0f;
            green=0.0f; break;

        default: return;
    }
    glutPostRedisplay();
}


void menuCor(int opcao){
    switch(opcao){
        case 0:
            red=1.0f;
            blue=1.0f;
            green=1.0f;
        break;
        case 1:
            red=1.0f;
            blue=0.0f;
            green=1.0f;
            break;
        case 2:
            red=0.0f;
            blue=1.0f;
            green=1.0f;
            break;
        case 3:
            red=1.0f;
            blue=1.0f;
            green=0.0f; break;
        default: return;
        break;
    }
    glutPostRedisplay();
}

void criaMenu(){
    int menu = glutCreateMenu(menuCor);
    glutAddMenuEntry("Branco", 0);
    glutAddMenuEntry("Amarelo", 1); // original: verde
    glutAddMenuEntry("Ciano", 2);
    glutAddMenuEntry("Magenta", 3);
    glutAttachMenu(GLUT_RIGHT_BUTTON);
}

int main(int argc, char** argv){
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glClearColor (0.0, 0.0, 1.0, 1.0);
    glutInitWindowSize (300, 300);
    glutInitWindowPosition (200, 200);
    glutCreateWindow (argv[0]);
    glutFullScreen();

    glutDisplayFunc(Desenha); // desenha as coisas na tela
    glutKeyboardFunc(Teclado);

    criaMenu();

    glutReshapeFunc(AlteraTamanhoJanela);
    glutTimerFunc(33, Timer, 1);
    glutMainLoop(); // loop para permanecer rodando
    return 0;
}
